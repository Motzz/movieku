var $$ = Dom7;

var device = Framework7.getDevice();
var app = new Framework7({
  name: "week2_160419007", // App name
  theme: "auto", // Automatic theme detection
  el: "#app", // App root element

  id: "io.framework7.myapp", // App bundle ID
  // App store
  store: store,
  // App routes
  routes: routes,

  // Input settings
  input: {
    scrollIntoViewOnFocus: device.cordova && !device.electron,
    scrollIntoViewCentered: device.cordova && !device.electron,
  },
  // Cordova Statusbar settings
  statusbar: {
    iosOverlaysWebView: true,
    androidOverlaysWebView: false,
  },
  on: {
    init: function () {
      var f7 = this;
      if (f7.device.cordova) {
        // Init cordova APIs (see cordova-app.js)
        cordovaApp.init(f7);
      }
    },
  },
});
var teletubbies = ["tinky winky", "dipsi", "lalaa", "po"];
var movies = [];
movies.push({
  judul: "Avenger Infinity War",
  sinopsis:
    "Iron Man, Thor, the Hulk and the rest of the Avengers unite to battle their most powerful enemy yet -- the evil Thanos. On a mission to collect all six Infinity Stones, Thanos plans to use the artifacts to inflict his twisted will on reality. ",
  poster: "https://ubaya.fun/images/1.jpg",
});
movies.push({
  judul: "Joker",
  sinopsis:
    "Forever alone in a crowd, failed comedian Arthur Fleck seeks connection as he walks the streets of Gotham City. Arthur wears two masks --       the one he paints for his day job as a clown, and the guise he projects in a futile attempt to feel like he is part of the world around him. ",
  poster: "https://ubaya.fun/images/2.jpg",
});
movies.push({
  judul: "OnWard",
  sinopsis:
    "Teenage elf brothers Ian and Barley embark on a magical quest to spend one more day with their late father.        Like any good adventure, their journey is filled with cryptic maps, impossible obstacles and unimaginable discoveries.",
  poster: "https://ubaya.fun/images/3.jpg",
});
movies.push({
  judul: "Knives Out",
  sinopsis:
    "The circumstances surrounding the death of crime novelist Harlan Thrombey are mysterious, but there is one thing that renowned Detective Benoit Blanc knows for sure -- everyone in the wildly dysfunctional Thrombey family is a suspect. ",
  poster: "https://ubaya.fun/images/4.jpg",
});
movies.push({
  judul: "Mulan",
  sinopsis: "A young Chinese maiden disguises herself as a male warrior in order to save her father. ",
  poster: "https://ubaya.fun/images/5.jpg",
});
movies.push({
  judul: "Tenet",
  sinopsis: "In a twilight world of international espionage, an unnamed CIA operative, known as The Protagonist, is recruited by a mysterious organization called Tenet to participate in a global assignment that unfolds beyond real time.",
  poster: "https://ubaya.net/images/5.jpg",
});
// <li>Valkyrie (Tessa Thompson)</li>
//             <li>Rocket Raccon (Bradley Cooper)</li>
//             <li>James Rhodes / War Machine (Don Cheadle)</li>
//             <li>Natasha Romanoff / Black Widow (Scarlett Johansson)</li>
//             <li>Clint Barton / Hawkeye (Jeremy Renner)</li>
//             <li>Steve Rogers / Captain America (Chris Evans)</li>
var actor = [];
actor.push({
  nama: "Valkyrie",
  biodata: "Salah satu aktor yang memerankan captain amerika pada serial avenger",
  foto: "https://cdn.kincir.com/1/production/media/2017/oktober/tessa-thompson/7-tessa-thompson-700x700.jpg",
});
actor.push({
  nama: "Rocket Raccon",
  biodata: "Salah satu aktor yang memerankan racoon serial avenger",
  foto: "https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/bradley-cooper-and-gloria-campano-attend-the-94th-annual-news-photo-1648420553.jpg",
});
actor.push({
  nama: "James Rhodes",
  biodata: "Salah satu aktor yang memerankan war machine pada serial avenger",
  foto: "https://static.wikia.nocookie.net/moviedatabase/images/a/a3/James_Rhodes.jpg",
});
actor.push({
  nama: "Natasha Romanoff",
  biodata: "Salah satu aktor yang memerankan hawkeye pada serial avenger ",
  foto: "https://i.pinimg.com/originals/14/e6/34/14e63434d7adeb7c87c35fb3b7f49d0d.png",
});
actor.push({
  nama: "Clint Barton",
  biodata: "Salah satu aktor pada serial avenger",
  foto: "https://www.slashfilm.com/img/gallery/how-hawkeye-makes-clint-barton-more-than-the-mcus-punching-bag-exclusive/l-intro-1637588432.jpg",
});
actor.push({
  nama: "Steve Rogers",
  biodata: "Salah satu aktor yang memerankan captain amerika pada serial avenger",
  foto: "https://i0.wp.com/screengeek.net/wp-content/uploads/2019/12/avengers-endgame-captain-america.jpg",
});

$$("#btn1").on("click", function () {
  app.dialog.alert("Halo aku adalah alert");
});

$$(document).on("page:init", function (e, page) {
  if (page.name == "theater") {
    // $$("#theater").html("<div class='block'><h1>DIUBAH VIA DOM7</h1></div>");
    // teletubbies.forEach((t) => {
    //   $$("#theater").append("<div class='block'><h1>" + t + "</h1></div>");
    // });
    var id = 0;
    movies.forEach((t) => {
      $$("#theater").append(
        "<div class='col-50'><div class='card'>" +
          "<div class='card-header'>" +
          t.judul +
          "</div><div class='card-content'>" +
          "<img src='" +
          t.poster +
          "' width='100%'>" +
          "</div><div class='caed-footer'><a  href='/detailmovie/" +
          id +
          "' class='button button-fill'>detail</a>" +
          "</div></div></div>"
      );
      id++;
    });
  }
  if (page.name == "aktor") {
    // $$("#theater").html("<div class='block'><h1>DIUBAH VIA DOM7</h1></div>");
    // teletubbies.forEach((t) => {
    //   $$("#theater").append("<div class='block'><h1>" + t + "</h1></div>");
    // });
    var id = 0;
    actor.forEach((t) => {
      $$("#aktor").append(
        "<div class='col-100'><div class='card'>" +
          "<div class='card-header'>" +
          t.nama +
          "</div><div class='card-content '>" +
          "<img src='" +
          t.foto +
          "' width='100%'>" +
          "</div><div class='caed-footer'><a  href='/detailaktor/" +
          id +
          "' class='button button-fill'>detail</a>" +
          "</div></div></div>"
      );
      id++;
    });
  }
  if (page.name == "detailmovie") {
    var id = page.router.currentRoute.params.id;
    $$("#detail").html(
      "<div class='card'>" +
        "<div class='card-header'>" +
        movies[id].judul +
        "</div><div class='card-content'>" +
        "<img src='" +
        movies[id].poster +
        "' width='100%'>" +
        "<br><div class='block'><p>" +
        movies[id].sinopsis +
        "</p></div> </div></div>"
    );
  }
  if (page.name == "detailaktor") {
    var id = page.router.currentRoute.params.id;
    $$("#detailaktor").html(
      "<div class='card'>" +
        "<div class='card-header'>" +
        actor[id].nama +
        "</div><div class='card-content'>" +
        "<img src='" +
        actor[id].foto +
        "' width='100%'>" +
        "<br><div class='block'><p>" +
        actor[id].biodata +
        "</p></div> </div></div>"
    );
  }
});
