var routes = [
  {
    path: "/",
    url: "./index.html",
  },
  {
    path: "/about",
    url: "./about.html",
  },
  {
    path: "/movies",
    url: "./movies.html",
  },
  {
    path: "/theater",
    url: "./theater.html",
  },
  {
    path: "/aktor",
    url: "./aktor.html",
  },
  {
    path: "/detailmovie/:id",
    url: "./detailmovie.html",
  },
  {
    path: "/detailaktor/:id",
    url: "./detailaktor.html",
  },
];
