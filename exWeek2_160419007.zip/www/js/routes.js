var routes = [
  {
    path: "/",
    url: "./index.html",
  },
  {
    path: "/about",
    url: "./about.html",
  },
  {
    path: "/movies",
    url: "./movies.html",
  },
];
